<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'D:/Development/GDP Accounts Traditional/grav/grav-admin/user/data/notifications/882430943a7f6ec18069e86c6f16f06f.yaml',
    'modified' => 1721334088,
    'size' => 7998,
    'data' => NULL
];
