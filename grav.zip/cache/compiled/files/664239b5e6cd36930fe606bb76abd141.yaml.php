<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'D:/Development/GDP Accounts Traditional/grav/grav-admin/user/plugins/page-inject/page-inject.yaml',
    'modified' => 1719437899,
    'size' => 70,
    'data' => [
        'enabled' => true,
        'active' => true,
        'processed_content' => false,
        'remote_injections' => NULL
    ]
];
