<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'D:/Development/GDP Accounts Traditional/grav/grav-admin/user/config/security.yaml',
    'modified' => 1719264349,
    'size' => 21,
    'data' => [
        'salt' => 'ZXD6jMPCH8B2ki'
    ]
];
