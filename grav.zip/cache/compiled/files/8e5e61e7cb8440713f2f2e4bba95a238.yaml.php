<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'D:/Development/GDP Accounts Traditional/grav/grav-admin/user/plugins/admin/languages/km.yaml',
    'modified' => 1715786242,
    'size' => 223,
    'data' => [
        'PLUGIN_ADMIN' => [
            'ADMIN_REPORT_ISSUE' => 'ឃើញមានបញ្ហាមែនទេ? សូមរាយការណ៍នៅលើ GitHub។',
            'LOGIN_BTN' => 'ចូល',
            'LOGIN_BTN_FORGOT' => 'ភ្លេចគណនី'
        ]
    ]
];
