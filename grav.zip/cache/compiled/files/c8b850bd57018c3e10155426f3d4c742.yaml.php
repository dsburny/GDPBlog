<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'D:/Development/GDP Accounts Traditional/grav/grav-admin/user/plugins/breadcrumbs/breadcrumbs.yaml',
    'modified' => 1719437888,
    'size' => 166,
    'data' => [
        'enabled' => true,
        'show_all' => true,
        'built_in_css' => true,
        'include_home' => true,
        'include_current' => true,
        'icon_home' => '',
        'icon_divider_classes' => 'fa fa-angle-right',
        'link_trailing' => false
    ]
];
