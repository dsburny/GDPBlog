<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'D:/Development/GDP Accounts Traditional/grav/grav-admin/user/data/flex/indexes/accounts.yaml',
    'modified' => 1719264497,
    'size' => 174,
    'data' => [
        'version' => '1.2',
        'timestamp' => 1719264497,
        'count' => 1,
        'index' => [
            'gdpamin' => [
                'storage_key' => 'gdpamin',
                'storage_timestamp' => 1719264496,
                'key' => 'gdpamin',
                'email' => 'dsburnside@hotmail.com'
            ]
        ]
    ]
];
