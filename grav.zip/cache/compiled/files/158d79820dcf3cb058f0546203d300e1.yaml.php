<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'D:/Development/GDP Accounts Traditional/grav/grav-admin/user/plugins/admin/languages/bn.yaml',
    'modified' => 1715786242,
    'size' => 95,
    'data' => [
        'PLUGIN_ADMIN' => [
            'LOGIN_BTN' => 'লগ ইন',
            'LOGIN_BTN_FORGOT' => 'ভুলে গেছি'
        ]
    ]
];
