<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'D:/Development/GDP Accounts Traditional/grav/grav-admin/user/data/notifications/gdpamin.yaml',
    'modified' => 1719438945,
    'size' => 38,
    'data' => [
        27 => 'Thu, 27 Jun 2024 00:55:45 +0300'
    ]
];
