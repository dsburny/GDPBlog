<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'themes://quark-open-publishing/quark-open-publishing.yaml',
    'modified' => 1719437947,
    'size' => 194,
    'data' => [
        'streams' => [
            'schemes' => [
                'theme' => [
                    'type' => 'ReadOnlyStream',
                    'prefixes' => [
                        '' => [
                            0 => 'themes://quark-open-publishing',
                            1 => 'themes://quark'
                        ]
                    ]
                ]
            ]
        ]
    ]
];
