<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'D:/Development/GDP Accounts Traditional/grav/grav-admin/user/data/feed/882430943a7f6ec18069e86c6f16f06f.yaml',
    'modified' => 1721252011,
    'size' => 1727,
    'data' => NULL
];
