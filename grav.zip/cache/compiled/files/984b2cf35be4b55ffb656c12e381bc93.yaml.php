<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'plugins://git-sync/git-sync.yaml',
    'modified' => 1719437896,
    'size' => 14,
    'data' => [
        'enabled' => true
    ]
];
