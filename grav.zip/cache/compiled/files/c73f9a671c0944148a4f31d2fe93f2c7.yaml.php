<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'plugins://pagination/pagination.yaml',
    'modified' => 1719437901,
    'size' => 42,
    'data' => [
        'enabled' => true,
        'built_in_css' => true,
        'delta' => 0
    ]
];
