<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'D:/Development/GDP Accounts Traditional/grav/grav-admin/user/plugins/taxonomylist/taxonomylist.yaml',
    'modified' => 1719437913,
    'size' => 29,
    'data' => [
        'enabled' => true,
        'route' => '/blog'
    ]
];
