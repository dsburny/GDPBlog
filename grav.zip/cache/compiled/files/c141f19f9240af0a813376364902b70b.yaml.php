<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'D:/Development/GDP Accounts Traditional/grav/grav-admin/user/plugins/admin/blueprints/admin/pages/move.yaml',
    'modified' => 1715786242,
    'size' => 66,
    'data' => [
        'form' => [
            'validation' => 'loose',
            'fields' => [
                'route' => [
                    'type' => 'hidden'
                ]
            ]
        ]
    ]
];
