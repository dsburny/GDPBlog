<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'D:/Development/GDP Accounts Traditional/grav/grav-admin/user/config/media.yaml',
    'modified' => 1719264497,
    'size' => 0,
    'data' => [
        
    ]
];
