<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'D:/Development/GDP Accounts Traditional/grav/grav-admin/user/plugins/page-as-data/page-as-data.yaml',
    'modified' => 1719869904,
    'size' => 13,
    'data' => [
        'enabled' => true
    ]
];
