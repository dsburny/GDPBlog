<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'D:/Development/GDP Accounts Traditional/grav/grav-admin/user/config/versions.yaml',
    'modified' => 1719264353,
    'size' => 65,
    'data' => [
        'core' => [
            'grav' => [
                'version' => '1.7.46',
                'schema' => '1.7.0_2020-11-20_1'
            ]
        ]
    ]
];
